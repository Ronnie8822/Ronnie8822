import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

export default function Team() {
  return (
    <div className="bg-gray-900 text-white min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow text-center py-20">
        <h2 className="text-3xl font-bold mb-4">Meet Our Team</h2>
        <p>Team members coming soon!</p>
      </main>
      <Footer />
    </div>
  );
}