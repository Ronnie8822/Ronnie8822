import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

export default function Features() {
  return (
    <div className="bg-gray-900 text-white min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow text-center py-20">
        <h2 className="text-3xl font-bold mb-4">Bot Features</h2>
        <ul className="list-disc list-inside">
          <li>24/7 Lofi Music</li>
          <li>Radio Support</li>
          <li>High Quality Filters</li>
        </ul>
      </main>
      <Footer />
    </div>
  );
}