import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

export default function Add() {
  return (
    <div className="bg-gray-900 text-white min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow text-center py-20">
        <h2 className="text-3xl font-bold mb-4">Invite Lofi Riya</h2>
        <a
          href="https://discord.com/oauth2/authorize?client_id=YOUR_BOT_ID&permissions=8&scope=bot+applications.commands"
          className="bg-pink-600 hover:bg-pink-700 px-6 py-3 rounded-full text-white"
        >
          Add To Discord
        </a>
      </main>
      <Footer />
    </div>
  );
}