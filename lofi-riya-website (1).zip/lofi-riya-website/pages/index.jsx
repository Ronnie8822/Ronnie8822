import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

export default function Home() {
  return (
    <div className="bg-gray-900 text-white min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow text-center py-20 px-4">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">Welcome to Lofi Riya</h1>
        <p className="text-lg text-gray-300 mb-8">Your ultimate chill Discord music bot.</p>
        <a
          href="/add"
          className="bg-pink-600 hover:bg-pink-700 text-white px-6 py-3 rounded-full transition"
        >
          Add Bot Now
        </a>
      </main>
      <Footer />
    </div>
  );
}