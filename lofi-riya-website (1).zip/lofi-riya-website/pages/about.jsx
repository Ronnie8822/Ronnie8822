import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

export default function About() {
  return (
    <div className="bg-gray-900 text-white min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow text-center py-20">
        <h2 className="text-3xl font-bold mb-4">About Lofi Riya</h2>
        <p>A chill and aesthetic Discord bot made for Lofi lovers.</p>
      </main>
      <Footer />
    </div>
  );
}