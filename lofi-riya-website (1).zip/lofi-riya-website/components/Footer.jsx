export default function Footer() {
  return (
    <footer className="bg-gray-800 text-gray-400 text-center p-4">
      © 2025 Lofi Riya. All rights reserved.
    </footer>
  );
}