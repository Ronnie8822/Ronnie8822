import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="bg-gray-800 p-4 flex justify-between items-center">
      <h1 className="text-xl font-bold text-pink-400">Lofi Riya</h1>
      <div className="space-x-4">
        <Link href="/">Home</Link>
        <Link href="/add">Add Bot</Link>
        <Link href="/features">Features</Link>
        <Link href="/developer">Developer</Link>
        <Link href="/team">Team</Link>
        <Link href="/about">About</Link>
      </div>
    </nav>
  );
}